<?php include_once("Header.php");?>
		
		<form id="DesignationPage">
					<div class="row">
						<div class="col-md-3 col-sm-2 col-xs-2">
						</div>
										
						<div class="col-md-2 col-sm-2 col-xs-2">
						<label for ="Desig">Designation</label>
						</div>
						
						<div class="col-md-3 col-sm-2 col-xs-2">
						 <input type="text" class="form-control" id="Desig" name="Desig" required="" placeholder="Enter Designation">
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-5 col-sm-2 col-xs-2">
						</div>
										
						<div class="col-md-1 col-sm-2 col-xs-12">
							<input type="submit" id="btnAdd" class="btn btn-info" value="Add">
						</div>
				<!--		<div class="col-md-1 col-sm-2 col-xs-12">
							<input type="button"id="btndel" class="btn btn-info" value="Delete">
						</div>	
						<div class="col-md-1 col-sm-2 col-xs-12">
							<input type="button"id="btnSrch" class="btn btn-info" value="Search">
						</div>-->
					</div>
									
				</form>
			<?php include_once("Footer.php");?>	





		<script>
			$( document ).ready(function() 
			{
			  $("#DesignationPage").submit(function(event){
					event.preventDefault(); //prevent default action 
					var request_method = $(this).attr("method"); //get form GET/POST method
					var form_data = $(this).serialize(); //Encode form elements for submission
					
					$.ajax({
						url : "DesignationSqlPage.php",
						type: request_method,
						data : form_data
					}).done(function(response){ 
							alert(response);
						//$("#server-results").html(response);
					});
				});
			});
		</script>
 