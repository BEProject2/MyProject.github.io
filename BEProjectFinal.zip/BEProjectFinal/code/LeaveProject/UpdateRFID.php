<?php include_once("Header.php");?>
<?php

	include("connection.php");
	//session_start();
	$EmployeeId=$_SESSION["EmployeeId"];
	$sql = "SELECT RFID_Number FROM rfid_details WHERE Employee_id ='$EmployeeId'";
	$result = $con->query($sql);

	if ($result->num_rows > 0) {
		$newRfidNumber=$result->fetch_object()->RFID_Number;
		//echo $newRfidNumber;
	} 
	else {
		$newRfidNumber=0;
	}
	//$con->close();
?>

		<center><h1>Update RFID Page</h1></center>
				<form id="UpdateRfidForm">
									
					<div class="row">
						<div class="col-md-3 col-sm-2 col-xs-12">
						</div>
										
						<div class="col-md-2 col-sm-2 col-xs-12">
						<label for ="lblOldRfid">Old RFID Number</label>
						</div>
						
						<div class="col-md-3 col-sm-2 col-xs-12">
						 <input type="text" class="form-control" id="oldrfid" name="oldrfid" required="" value="<?php echo $newRfidNumber;?>">
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-3 col-sm-2 col-xs-12">
						</div>
										
						<div class="col-md-2 col-sm-2 col-xs-12">
						<label for ="lblNewRfid">New RFID Number</label>
						</div>
						
						<div class="col-md-3 col-sm-2 col-xs-12">
							<input type="text" class="form-control" id="newrfid" name="newrfid" required="" placeholder="Enter New RFID Number">
						</div>
					</div>
						
					<div class="row">
						<div class="col-md-5 col-sm-2 col-xs-12">
						</div>
										
						<div class="col-md-2 col-sm-2 col-xs-12">
							<input type="submit"id="btnSave" class="btn btn-info" value="Submit">
						</div>
					</div>

				</form>
<?php include_once("Footer.php");?>
		
		<script>
			$( document ).ready(function(event) 
			{
					 
			  $("#UpdateRfidForm").submit(function(event){
					
					event.preventDefault(); //prevent default action 
					
					var request_method = $(this).attr("method"); //get form GET/POST method
					var form_data = $(this).serialize(); //Encode form elements for submission
					$.ajax({
						
						url : "UpdateRFIDSqlPage.php",
						type: request_method,
						data : form_data
					}).done(function(response){ 
					
							alert(response);
							document.getElementById("oldrfid").value = "";
							document.getElementById("newrfid").value = "";
					});
				});
			});
		</script>

