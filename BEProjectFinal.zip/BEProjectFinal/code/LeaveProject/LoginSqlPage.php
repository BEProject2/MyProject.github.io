<?php
	include("connection.php");
	$UserName=$_GET["UserName"];
	$Password=$_GET["Password"];
	
	$query=mysqli_query($con,"SELECT * from login_details WHERE Username='$UserName' AND Password='$Password'");
	$numrows=mysqli_num_rows($query); 
	
	if($numrows!=0)
	{
		$empId=$query->fetch_object()->Employee_id;
		session_start();
		$_SESSION["EmployeeId"]=$empId;
		$_SESSION["UserName"]=$UserName;
		//$_SESSION["UserName"]=$UserName;
		$_SESSION["UserId"]=$empId;

		$sql1 = mysqli_query($con,"SELECT * FROM employee_details WHERE Employee_id='$empId'");
		$desgId=$sql1->fetch_object()->Designation_id;
		$sql2 = mysqli_query($con,"SELECT * FROM designation_details WHERE Designation_id='$desgId'");
		$designation=$sql2->fetch_object()->Designation;
		
		$_SESSION["Role"]=$designation;
		//$_SESSION["DepartmentId"]=$deptId;
		echo "Login Successful";
	}
	else
		echo "Login Failed";
?>