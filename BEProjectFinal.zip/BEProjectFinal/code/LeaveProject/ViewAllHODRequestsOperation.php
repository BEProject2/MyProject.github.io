<?php
	include("connection.php");
	session_start();
	$EmployeeId=$_SESSION["EmployeeId"];
	//To get Department Id of currently loggged in user
	$ida= mysqli_query($con,"SELECT Department_id FROM employee_details WHERE Employee_id='$EmployeeId'");
	$dept_id=$ida->fetch_object()->Department_id;
	
	//Get Current Month	
	$month = $_POST["month"];
	//echo $month;
	//Fetch All Employee Requests of same department same as subAdmin i.e. $dept_id
	$sql = "SELECT a.Leave_id,a.Employee_id,a.Leave_type,a.Leave_reason,a.Leave_date,a.From_time,a.To_time,a.Total_Leave_Hours,a.Status,b.Department_id FROM leave_details as a,employee_details as b WHERE a.Employee_id=b.Employee_id AND b.Designation_id=5";
	$result = $con->query($sql);

	if ($result->num_rows > 0) {
		echo "<table class='table'><tr><th>LeaveId</th><th>EmployeeId</th><th>LeaveType</th><th>LeaveReason</th><th>LeaveDate</th><th>LeaveFromTime</th><th>LeaveToTime</th><th>TotalLeaveHours</th><th>Status</th></tr>";

		while($row = $result->fetch_assoc()) {
			$leaveId=$row["Leave_id"];
			$empId=$row["Employee_id"];
			$LeaveType=$row["Leave_type"];
			$LeaveReason=$row["Leave_reason"];
			$LeaveDate=$row["Leave_date"];
			//Getting month from LeaveDate
			$now1 = new DateTime($LeaveDate);
			$month1 = $now1->format('m');
			$LeaveFromTime=$row["From_time"];
			$LeaveToTime=$row["To_time"];
			$LeaveTotalHours=$row["Total_Leave_Hours"];
			$Status=$row["Status"];		
			if($month==$month1)
				echo "<tr><td>".$leaveId."</td><td>".$empId."</td><td>".$LeaveType."</td><td>".$LeaveReason."</td><td>".$LeaveDate."</td><td>".$LeaveFromTime."</td><td>".$LeaveToTime."</td><td>".$LeaveTotalHours."</td><td>".$Status."</td></tr>";
		}
		echo "</table>";
	} 
	else {
		echo "No more Requests";
	}
	//$con->close();
?>
