<?php
		include("connection.php");
// Perform queries
 
		$id=mysqli_query($con,"SELECT * from department_details");
		while($rw=mysqli_fetch_array($id))
		{
		$dept_id=$rw["Department_id"];
		$Department=$rw["Department"];
		echo "<option value='$dept_id'>$Department</option>";
		}

	//mysqli_close($con);
?>