<?php include_once("Header.php");?>

<?php

	include("connection.php");
	//session_start();
	$EmployeeId=$_SESSION["EmployeeId"];
	//To get Department Id of currently loggged in user
	$ida= mysqli_query($con,"SELECT Department_id FROM employee_details WHERE Employee_id='$EmployeeId'");
	$dept_id=$ida->fetch_object()->Department_id;
	
	//Fetch All Employee Requests of same department same as subAdmin i.e. $dept_id which are pending
	$sql = "SELECT a.Leave_id,a.Employee_id,b.Department_id FROM leave_details as a,employee_details as b WHERE a.Employee_id=b.Employee_id AND a.Status='Pending' AND b.Designation_id!=5 AND b.Department_id='$dept_id'";
	$result = $con->query($sql);

	if ($result->num_rows > 0) {
		echo "<table class='table'><tr><th>Leave Id</th><th>Employee Id</th><th>View Details</th></tr>";

		while($row = $result->fetch_assoc()) {
			$leaveId=$row["Leave_id"];
			$empId=$row["Employee_id"];
			//$sql1 = "SELECT Employee_Name FROM employee_details WHERE Employee_id ='$empId'";
			//$empName=$sql1->fetch_object()->Employee_Name;
			echo "<tr><td>".$leaveId."</td><td>".$empId."</td><td><a href='' onclick='shodetails($leaveId)' data-toggle='modal' data-target='#myModal'>View</a></td></tr>";
		}
		echo "</table>";
	} 
	else {
		echo "No more Requests";
	}
	//$con->close();
?>

	<div class="modal fade" id="myModal" role="dialog">
		<div class="modal-dialog">
		  <!-- Modal content-->
		  <div class="modal-content">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal">&times;</button>
			  <h4 class="modal-title">Leave Request Details</h4>
			</div>
			<div class="modal-body" id='modalresponse'>
			
			
			</div>
			<div class="modal-footer">
						<button type="button" id="close" name="close" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		  </div>		  
		</div>
  </div>

<?php include_once("Footer.php");?>

  
	<script>
		
		    function Change1(leaveid,status)
		  {
		   var radioValue = $("input[name='LeaveStatus']:checked").val();
				if(radioValue=="Accept")
				{
					$('#commentText').css('display','none');
				}
				if(radioValue=="Reject")
				{
					$('#commentText').css('display','block');
				}
		  }
		  function save(leaveid)
		  {
		  var radioValue = $("input[name='LeaveStatus']:checked").val();
		  var comment = $("#comment").val();
		  
		  //var comment=document.getElementById('comment').value;
		  	$.post("UpdateRequestPage.php",
				{
					Flag:"UpdateD",
					Leave_id:leaveid,
					Status:radioValue,
					Comment:comment
				},function(data,success)
				{
					alert(data);
					$('#myModal').modal('hide');
					window.location.reload(true);
				});
		  }
		  function shodetails(leaveid)
		  {
			$.post("ViewRequestPage_Operations.php",
			{
				leaveid: leaveid
			},
			function(data, status)
			{
				//alert(data);
				$("#modalresponse").html(data);
				//alert("Data: " + data + "\nStatus: " + status);
			});
		  }
	</script>
		
		
		