<?php include_once("Header.php");?>
<?php
	include("connection.php");
	//session_start();
	$EmployeeId=$_SESSION["EmployeeId"];
	//Getting records from leave_details and scanner_details for current logged in employee for their leave request
	$sql = "SELECT a.Leave_id,a.Leave_type,a.Leave_reason,a.Leave_date,a.From_time,a.To_time,b.Scan_From_time,b.Scan_To_time FROM leave_details a,rfid_scanner_details b WHERE Employee_id ='$EmployeeId' AND a.Leave_id=b.Leave_id";
	$result = $con->query($sql);
	
	if ($result->num_rows > 0) {
		
		echo "<table class='table'><tr><th>Leave_Id</th><th>Leave_Type</th><th>Leave_reason</th><th>Leave_date</th><th>From_time</th><th>To_time</th><th>Swipped From_time</th><th>Swipped To_time</th><th>Difference</th><th>Comment</th></tr>";

		while($row = $result->fetch_assoc()) 
		{
			$leave_id=$row["Leave_id"];
			$leave_type=$row["Leave_type"];
			$leave_reason=$row["Leave_reason"];
			$leave_date=$row["Leave_date"];
			$leave_fromTime=$row["From_time"];
			$leave_toTime=$row["To_time"];
			$swippedFromTime=$row["Scan_From_time"];
			$swippedToTime=$row["Scan_To_time"];
			
			//Getting Comment From Comment_details for that leave_id
			$sql1 = "SELECT Time_Difference,Comment FROM comment_details WHERE Leave_id ='$leave_id'";
			$result1 = $con->query($sql1);	
			
			$timeDiff=$comment="";
			if($result1->num_rows > 0)
			{
				while($row1 = $result1->fetch_assoc()) 
				{
					$timeDiff = $row1["Time_Difference"];
					$comment = $row1["Comment"];
				}
			}	
			else
			{
				$timeDiff = "";
				$comment = "";
			}
			echo "<tr><td>".$leave_id."</td><td>".$leave_type."</td><td>".$leave_reason."</td><td>".$leave_reason."</td><td>".$leave_fromTime."</td><td>".$leave_toTime."</td><td>".$swippedFromTime."</td><td>".$swippedToTime."</td><td>".$timeDiff."</td><td>".$comment."</td></tr>";
			
		}
		echo "</table>";
	} else {
		echo "0 results";
	}
	//$con->close();
?>
<?php include_once("Footer.php");?>