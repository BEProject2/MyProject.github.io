<?php include_once("Header1.php");?>
			<center><h3>Forget Password Page</h3></center>
			<form id="ForgetPasswordPage" method="post" action="">
					<div class="row">
						<div class="col-md-3 col-sm-2 col-xs-2">
						</div>
										
						<div class="col-md-2 col-sm-2 col-xs-2">
						<label for ="LblEmailID">Email ID</label>
						</div>
						
						<div class="col-md-3 col-sm-2 col-xs-2">
						 <input type="email" class="form-control" id="EmailId" name="EmailId" required="" placeholder="Enter Email ID">
						</div>
					</div>
					
					
					<div class="row">
						<div class="col-md-5 col-sm-2 col-xs-2">
						</div>
										
						<div class="col-md-1 col-sm-2 col-xs-12">
							<input type="submit" name="submit" class="btn btn-info" value="Get">
						</div>
						<div class="col-md-1 col-sm-2 col-xs-12">
							<input type="submit" name="cancel" class="btn btn-info" value="cancel">
						</div>	
						
					</div>
				</form>
<?php include_once("Footer1.php");?>	
<?php
if(isset($_POST['submit'])) 
{ 
	include("connection.php");
	$email = $_POST['EmailId']; 
	$query=mysqli_query($con,"SELECT Employee_id from employee_details WHERE Email_id='$email'");
	$numrows=mysqli_num_rows($query); 
	
	if($numrows!=0)
	{
		$Employee_id=$query->fetch_object()->Employee_id;
		$query=mysqli_query($con,"SELECT Password from login_details WHERE Employee_id='$Employee_id'");
		$Password=$query->fetch_object()->Password;
		
		$Subject="Password Request";
		$Body=$Password;
		$To=$email;
		include_once("mail.php");
		SendMail($Subject,$Body,$To);
		//echo "Mail Sent";
	}
	else{}	
	
}
else if(isset($_POST["cancel"])) 
{ 
	echo "<script>location.href='Login.php'</script>";
}

?>
