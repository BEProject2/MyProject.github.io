<?php
	include("connection.php");
	$oldrfid=$_GET["oldrfid"];
	$newrfid=$_GET["newrfid"];
	
	$now=date('Y-m-d');
	$expirationDate = date('Y-m-d', strtotime('+5 years'));

	if(mysqli_query($con,"update rfid_details set RFID_Number='$newrfid',Allocation_date='$now',Expiration_date='$expirationDate' where RFID_Number='$oldrfid'"))
	{
		echo "Updated";
	}
	else
	{
		echo "Failed";
	}

?>