<?php
		include("connection.php");
	  
		$Desig=$_GET["Desig"];
	
	// Perform queries
		if(mysqli_query($con,"INSERT INTO designation_details(Designation) VALUES ('$Desig')"))
		{
				echo"Success";
		}
		else
		{
			echo"Failed";
		}

		//mysqli_close($con);
?>