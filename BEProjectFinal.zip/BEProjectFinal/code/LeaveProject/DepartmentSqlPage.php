<?php
		include("connection.php");
		$Dept_Name=$_GET["Dept_Name"];
		$Dept_Abbreviation=$_GET["Dept_Abbreviation"];
		// Perform queries
		if(mysqli_query($con,"INSERT INTO department_details(Department,Abbreviation) VALUES ('$Dept_Name','$Dept_Abbreviation')"))
		{
				echo"Success";
		}
		else
		{
			echo"Failed";
		}
		//mysqli_close($con);
?>