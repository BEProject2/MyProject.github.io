<?php
session_start();
unset($_SESSION['UserName']);
unset($_SESSION['Role']);
session_destroy();
echo "<script>window.location='Login.php';</script>";
?> 