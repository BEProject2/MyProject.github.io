<?php
include_once("mail.php");
SendMail($Subject,$Body,$To);
?>