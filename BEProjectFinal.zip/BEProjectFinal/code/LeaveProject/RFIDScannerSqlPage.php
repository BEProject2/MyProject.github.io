<?php
		include("connection.php");
		session_start();
		
		$RFIDNo=$_GET["rfid_no"];
		$Date=$_GET["Date"];
		$FromTime=$_GET["FromTime"];
		$ToTime=$_GET["ToTime"];
		
		$ida= mysqli_query($con,"SELECT Employee_id FROM RFID_details WHERE RFID_Number='$RFIDNo'");
		$emp_id=$ida->fetch_object()->Employee_id;
	
		
		$ida1= mysqli_query($con,"SELECT Leave_id FROM leave_details WHERE Leave_date='$Date' AND Employee_id='$emp_id'");
		$leave_id=$ida1->fetch_object()->Leave_id;
	
		
		$time1 = new DateTime($FromTime);
		$time2 = new DateTime($ToTime);
		$interval = $time1->diff($time2);
		echo $totalHours=$interval->format('%h:%i:%s');
		//$totalHours=$ToTime-$FromTime;
		//$totalHours  = $FromTime->diff($ToTime); 
		//echo $RFIDNo." ".$Date." ".$FromTime." ".$ToTime." ".$interval;
		
	// Perform queries
		if(mysqli_query($con,"INSERT INTO rfid_scanner_details(Leave_id,RFID_Number,Scan_date,Scan_From_time,Scan_To_time,Scan_Total_Hours) VALUES('$leave_id','$RFIDNo','$Date','$FromTime','$ToTime','$totalHours')"))
		{
				echo"Success";
		}
		else
		{
			echo"Failed";
		}
		//mysqli_close($con);
?>