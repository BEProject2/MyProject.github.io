<?php
	$con=mysqli_connect("localhost","root","","be_project");
	if ($con->connect_error) {
		die("Connection failed: " . $con->connect_error);
	}
?>