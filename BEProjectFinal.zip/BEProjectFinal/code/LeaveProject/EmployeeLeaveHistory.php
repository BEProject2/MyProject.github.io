<?php include_once("Header.php");?>
<?php

	include("connection.php");
	//session_start();
	$EmployeeId=$_SESSION["UserId"];
	$sql = "SELECT Leave_id,Leave_type,Leave_reason,Leave_date,From_time,To_time,Total_Leave_Hours,Status FROM leave_details WHERE Employee_id ='$EmployeeId'";
	$result = $con->query($sql);

	if ($result->num_rows > 0) {
		echo "<table class='table'><tr><th>Leave_Id</th><th>Leave_Type</th><th>Leave_reason</th><th>Leave_date</th><th>From_time</th><th>To_time</th><th>Total_Leave_Hours</th><th>Status</th></tr>";

		while($row = $result->fetch_assoc()) {
			echo "<tr><td>".$row["Leave_id"]."</td><td>".$row["Leave_type"]."</td><td>".$row["Leave_reason"]."</td><td>".$row["Leave_date"]."</td><td>".$row["From_time"]."</td><td>".$row["To_time"]."</td><td>".$row["Total_Leave_Hours"]."</td><td>".$row["Status"]."</td></tr>";
		}
		echo "</table>";
	} else {
		echo "0 results";
	}
	//$con->close();
?>
<?php include_once("Footer.php");?>