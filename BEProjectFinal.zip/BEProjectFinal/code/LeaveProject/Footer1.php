           
                <!-- /.right-sidebar -->
            </div>
            <!-- /.container-fluid -->
            <footer class="footer text-center"><?php echo date("Y");?> &copy; <a href="www.witsolapur.org">Walchand Institute Of Technology,Solapur</a><img src="plugins/images/users/logo.jpg" width="50" Height="65"></footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
	<script src="plugins/bower_components/sweetalert/sweetalert.min.js"></script>
    <script src="plugins/bower_components/jquery/dist/jquery.min.js"></script>
	 <script src="plugins/bower_components/datatables/jquery.dataTables.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/dist/js/tether.min.js"></script>
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!--Morris JavaScript -->
    <!--<script src="plugins/bower_components/raphael/raphael-min.js"></script>
    <script src="plugins/bower_components/morrisjs/morris.js"></script>-->
    <!-- Sparkline chart JavaScript -->
    <script src="plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js"></script>
    <script src="plugins/bower_components/jquery-sparkline/jquery.charts-sparkline.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.min.js"></script>
				
				<!--Model-->
	
	<div id="myDocument" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Document upload</h4>
			</div>
			<div class="modal-body">
				<form id="frmDocument">
					<div class="row">
						<label class="col-md-4 control-label">Document Name</label>
						<div class="col-md-8 control-label">
							<input type="hidden" class="form-control" id="txtCustomerIdDocument" name="txtCustomerIdDocument">						
							<input type="text" class="form-control" id="txtDocumentName" name="txtDocumentName" required>						
						</div>
					</div><br>
					<div class="row">
						<label class="col-md-4 control-label">Document Upload</label>
						<div class="col-md-8 control-label">
							<input type="file" class="form-control" id="txtDocumentUpload" name="txtDocumentUpload" required>						
						</div>
					</div><br>
					<div class="row">
						<label class="col-md-10 control-label"></label>
						<div class="col-md-2 control-label">
							<input type="submit" class="btn btn-info" id="btnSave" name="btnSave" value="Save">					
						</div>
					</div>
					<!--<div class="row">
						<div class="col-md-offset-4 control-label">
							<input type="submit" class="btn btn-info" id="btnSave" name="btnSave" value="Save">						
						</div>
					</div>-->
				</form><br><br>
				<div id="DivShowDoc"></div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
   <!-- <script src="js/dashboard1.js"></script>-->
    <!--Style Switcher -->
    <script src="plugins/bower_components/styleswitcher/jQuery.style.switcher.js"></script>
	<script src="plugins/bower_components/custom-select/custom-select.min.js" type="text/javascript"></script>
	<script src="plugins/bower_components/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script> 
</body>

</html>
