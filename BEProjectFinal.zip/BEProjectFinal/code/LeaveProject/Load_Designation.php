<?php
	include("connection.php");
// Perform queries
 
		$id=mysqli_query($con,"SELECT * from designation_details");
		while($rw=mysqli_fetch_array($id))
		{
			$desig=$rw["Designation_id"];
			$Designation=$rw["Designation"];
			echo "<option value='$desig'>$Designation</option>";
		}
	//mysqli_close($con);
?>