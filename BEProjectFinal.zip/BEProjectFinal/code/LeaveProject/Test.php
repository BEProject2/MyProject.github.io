<?php include_once("Header.php");?>
	<h1>Hello</h1>
<?php include_once("Footer.php");?>