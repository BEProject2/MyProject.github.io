<?php
		include("connection.php");
		session_start();
		
		$empId=$_SESSION["EmployeeId"];  
		$LeaveType=$_GET["LeaveType"];
		$LeaveReason=$_GET["LeaveReason"];
		$Date=$_GET["Date"];
		$FromTime=$_GET["FromTime"];
		$ToTime=$_GET["ToTime"];
	
		$time1 = new DateTime($FromTime);
		$time2 = new DateTime($ToTime);
		$interval = $time1->diff($time2);
		echo $totalHours=$interval->format('%h:%i:%s');
		//$totalHours=$ToTime-$FromTime;
		//$totalHours  = $FromTime->diff($ToTime); 
		echo $empId." ".$LeaveType." ".$LeaveReason." ".$Date." ".$FromTime." ".$totalHours;
		
	// Perform queries
		if(mysqli_query($con,"INSERT INTO leave_details(Employee_id,Leave_type,Leave_reason,Leave_date,From_time,To_time,Total_Leave_Hours,Status) VALUES ('$empId','$LeaveType','$LeaveReason','$Date','$FromTime','$ToTime','$totalHours','Pending')"))
		{
				echo"Leave Request Sent Successfully";
		}
		else
		{
			echo"Leave Request Failed";
		}
		//mysqli_close($con);
?>