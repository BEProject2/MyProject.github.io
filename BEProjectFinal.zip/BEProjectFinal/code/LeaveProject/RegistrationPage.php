<?php include_once("Header1.php");?>

		<center><h1>Registration Page</h1></center>
				<form id="RegForm">
									
					<div class="row">
						<div class="col-md-3 col-sm-2 col-xs-12">
						</div>
										
						<div class="col-md-2 col-sm-2 col-xs-12">
						<label for ="EmpName">Employee Name</label>
						</div>
						
						<div class="col-md-3 col-sm-2 col-xs-12">
						 <input type="text" class="form-control" id="EmpName" name="EmpName" required="" placeholder="Enter name">
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-3 col-sm-2 col-xs-12">
						</div>
										
						<div class="col-md-2 col-sm-2 col-xs-12">
						<label for ="Deptname">Department Name</label>
						</div>
						
						<div class="col-md-3 col-sm-2 col-xs-12">
							<select class="form-control" id="dept" name="dept" placeholder="Choose">
							</select>
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-3 col-sm-2 col-xs-12">
						</div>
										
						<div class="col-md-2 col-sm-2 col-xs-12">
						<label for ="Desig">Designation</label>
						</div>
						
						<div class="col-md-3 col-sm-2 col-xs-12">
							<select class="form-control" id="desig" name="desig" placeholder="Choose">
							</select>
						</div>	
					</div>
					
					<div class="row">
						<div class="col-md-3 col-sm-2 col-xs-12">
						</div>
										
						<div class="col-md-2 col-sm-2 col-xs-12">
						<label for ="Emailid">Email Id</label>
						</div>
						
						<div class="col-md-3 col-sm-2 col-xs-12">
						 <input type="Email" class="form-control" id="EmailID"  name="EmailID" required=""  placeholder="Enter Email">
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-3 col-sm-2 col-xs-12">
						</div>
										
						<div class="col-md-2 col-sm-2 col-xs-12">
						<label for ="Cntct">Contact Number</label>
						</div>
						
						<div class="col-md-3 col-sm-2 col-xs-12">
						 <input type="text" class="form-control" id="Cntct" name="Cntct" required=""  placeholder="Enter Contact Number">
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-3 col-sm-2 col-xs-12">
						</div>
										
						<div class="col-md-2 col-sm-2 col-xs-12">
						<label for ="Uname">Username</label>
						</div>
						
						<div class="col-md-3 col-sm-2 col-xs-12">
						 <input type="text" class="form-control" id="Uname" name="Uname" required=""  placeholder="Enter Username">
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-3 col-sm-2 col-xs-12">
						</div>
										
						<div class="col-md-2 col-sm-2 col-xs-12">
						<label for ="Pwd">Password</label>
						</div>
						
						<div class="col-md-3 col-sm-2 col-xs-12">
						 <input type="Password" class="form-control" id="Pwd" name="Pwd" required=""  placeholder="Enter Password">
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-3 col-sm-2 col-xs-12">
						</div>
										
						<div class="col-md-2 col-sm-2 col-xs-12">
						<label for ="LblRfid">RFID Number</label>
						</div>
						
						<div class="col-md-3 col-sm-2 col-xs-12">
						 <input type="text" class="form-control" id="rfid" name="rfid" required=""  placeholder="Enter RFID Number">
						</div>
					</div>
					
						
					<div class="row">
						<div class="col-md-5 col-sm-2 col-xs-12">
						</div>
										
						<div class="col-md-2 col-sm-2 col-xs-12">
							<input type="submit"id="btnSave" class="btn btn-info" value="Submit">
						</div>
					</div>

				</form>
			<?php include_once("Footer1.php");?>
		

		<script>
			$( document ).ready(function(event) 
			{
					 $.post("Load_Department.php", function(data, status)
					 {
							$("#dept").html(data);
					 });
					$.post("Load_Designation.php", function(data)
					 {
						$("#desig").html(data);
					 });
					 
			  $("#RegForm").submit(function(event){
					event.preventDefault(); //prevent default action 
					var request_method = $(this).attr("method"); //get form GET/POST method
					var form_data = $(this).serialize(); //Encode form elements for submission
					$.ajax({
						url : "RegistrationSqlPage.php",
						type: request_method,
						data : form_data
					}).done(function(response){ 
					
							alert(response);
							document.getElementById("EmpName").value = "";
							document.getElementById("dept").value = "";
							document.getElementById("desig").value = "";
							document.getElementById("EmailID").value = "";
							document.getElementById("Cntct").value = "";
							document.getElementById("Uname").value = "";
							document.getElementById("Pwd").value = "";
							document.getElementById("rfid").value = "";
					});
				});
			});
		</script>

