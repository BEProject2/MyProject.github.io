<?php include_once("Header.php");?>
<?php
	include("connection.php");
	//session_start();
	$EmployeeId=$_SESSION["EmployeeId"];
	$query=mysqli_query($con,"SELECT dp.Department from employee_details as emp,department_details as dp WHERE emp.Employee_id='$EmployeeId' and dp.Department_id=emp.Department_id");
	$numrows=mysqli_num_rows($query); 
	
	if($numrows!=0)
	{
		$Department=$query->fetch_object()->Department;
		$query=mysqli_query($con,"SELECT Employee_Name from employee_details WHERE Employee_id='$EmployeeId'");
		$Employee_Name=$query->fetch_object()->Employee_Name;
		//echo $Employee_Name;
	}
?>
<center><h1>Leave Request Page</h1></center>

		<form id="LeaveRequestPage">
			<div class="row">
				<div class="col-md-8 col-sm-8 col-xs-12">
				
				</div>
				<div class="col-md-2 col-sm-2 col-xs-12">
					<label for="Lbl_Employee_ID">Employee ID</label><?php echo $_SESSION["EmployeeId"]; ?>
				</div>
			</div>	

			<div class="row">
				<div class="col-md-8 col-sm-8 col-xs-12">
				
				</div>
				<div class="col-md-3 col-sm-2 col-xs-12">
					<label for="Lbl_Employee_Name">Employee Name</label><?php echo $Employee_Name;?>
				</div>
			</div>		
				
			<div class="row">	
				<div class="col-md-8 col-sm-8 col-xs-12">
				
				</div>
				<div class="col-md-3 col-sm-2 col-xs-12">
					<label for="Lbl_Department_Name">Department Name</label><?php echo $Department;?>
				</div>
			</div>
			
			<div class="row">	
				<div class="col-md-2 col-sm-2 col-xs-12">
				
				</div>
				<div class="col-md-2 col-sm-2 col-xs-12">
					<label for="Lbl_Leave_Type">Leave Type</label>
				</div>
				<div class="col-md-2 col-sm-2 col-xs-12">	
					<input type="radio" class="" name="LeaveType" id="LeaveType" value="Organization">Organization
				</div>
				<div class="col-md-2 col-sm-2 col-xs-12">	
					<input type="radio" class="" name="LeaveType" id="LeaveType" value="Personal">Personal
				</div>
			</div>
						
			<div class="row">	
				<div class="col-md-2 col-sm-2 col-xs-12">
				
				</div>
				<div class="col-md-2 col-sm-2 col-xs-12">
					<label for="Lbl_LeaveReason">Leave Reason</label>
				</div>
				<div class="col-md-4 col-sm-2 col-xs-12">	
					<input type="text" id="LeaveReason" name="LeaveReason" class="form-control" required="" placeholder="Enter Leave Reason">
				</div>
			</div>
			
			<div class="row">	
				<div class="col-md-2 col-sm-2 col-xs-12">
				
				</div>
				<div class="col-md-2 col-sm-2 col-xs-12">
					<label for="Lbl_Date">Date</label>
				</div>
				<div class="col-md-4 col-sm-2 col-xs-12">	
					<input type="Date" name="Date" id="Date" required="" class="form-control">
				</div>
			</div>
			
			<div class="row">	
				<div class="col-md-2 col-sm-2 col-xs-12">
				
				</div>
				<div class="col-md-2 col-sm-2 col-xs-12">
					<label for="Lbl_Time">Time</label>
				</div>
				<div class="col-md-1 col-sm-2 col-xs-12">
					<label for="Lbl_FromTime">FromTime</label>
				</div>
				<div class="col-md-2 col-sm-2 col-xs-12">	
					<input type="Time" name="FromTime" id="FromTime" required="" class="form-control">
				</div>
				<div class="col-md-1 col-sm-2 col-xs-12">
					<label for="Lbl_ToTime">ToTime</label>
				</div>
				<div class="col-md-2 col-sm-2 col-xs-12">	
					<input type="Time" name="ToTime" id="ToTime" required="" class="form-control">
				</div>
			</div>
			
			<div class="row">	
				<div class="col-md-5 col-sm-2 col-xs-12">
				
				</div>
				<div class="col-md-2 col-sm-2 col-xs-12">
					<input type="submit" id="Submit" class="btn btn-info" Value="Send Request">
				</div>
			</div>
			
		</form>
<?php include_once("Footer.php");?>
<script>
			$( document ).ready(function() 
			{
			  $("#LeaveRequestPage").submit(function(event){
					event.preventDefault(); //prevent default action 
					var request_method = $(this).attr("method"); //get form GET/POST method
					var form_data = $(this).serialize(); //Encode form elements for submission
					
					$.ajax({
						url : "LeaveRequestSqlPage.php",
						type: request_method,
						data : form_data
					}).done(function(response){ 
							//alert(response);
							alert("Leave request sent");
						//$("#server-results").html(response);
							document.getElementById("LeaveType").value = "";
							document.getElementById("LeaveReason").value = "";
							document.getElementById("Date").value = "";
							document.getElementById("FromTime").value = "";
							document.getElementById("ToTime").value = "";
							
					});
				});
			});
		</script>

		