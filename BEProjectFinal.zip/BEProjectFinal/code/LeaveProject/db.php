<?php

mysql_connect("localhost","root","");
mysql_select_db("dbmhetras");

	$db = new PDO('mysql:host=localhost;dbname=dbmhetras;charset=utf8mb4', 'root', '');
	//$db = new PDO('mysql:host=localhost;dbname=dbpadmashalitesting;charset=utf8mb4', 'newsoftp_NSAdmin', 'NS@2624313');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
//$db->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false);
date_default_timezone_set("Asia/Kolkata");

?>
