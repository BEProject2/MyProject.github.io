<?php include_once("Header.php");?>
				<form id="DepartmentPage">
					<div class="row">
						<div class="col-md-3 col-sm-2 col-xs-2">
						</div>
										
						<div class="col-md-2 col-sm-2 col-xs-2">
						<label for ="Dept_Name">Department Name</label>
						</div>
						
						<div class="col-md-3 col-sm-2 col-xs-2">
						 <input type="text" class="form-control" id="Dept_Name" name="Dept_Name" required="" placeholder="Enter Department">
						</div>
					</div>
					<div class="row">
						<div class="col-md-3 col-sm-2 col-xs-2">
						</div>
										
						<div class="col-md-2 col-sm-2 col-xs-2">
						<label for ="Lbl_Dept_Abbreviation">Department Abbreviation</label>
						</div>
						
						<div class="col-md-3 col-sm-2 col-xs-2">
						 <input type="text" class="form-control" id="Dept_Abbreviation" name="Dept_Abbreviation" required="" placeholder="Enter Department Short Form">
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-5 col-sm-2 col-xs-2">
						</div>
										
						<div class="col-md-1 col-sm-2 col-xs-12">
							<input type="submit"id="btnSave" class="btn btn-info" value="Add">
						</div>
						<!--<div class="col-md-1 col-sm-2 col-xs-12">
							<input type="submit"id="btnSave" class="btn btn-info" value="Delete">
						</div>	
						<div class="col-md-1 col-sm-2 col-xs-12">
							<input type="submit"id="btnSave" class="btn btn-info" value="Search">
						</div>-->
					</div>
					
				</form>	

	<?php include_once("Footer.php");?>				
				
				
		
		<script>
			$( document ).ready(function() 
			{
			  $("#DepartmentPage").submit(function(event){
					event.preventDefault(); //prevent default action 
					var request_method = $(this).attr("method"); //get form GET/POST method
					var form_data = $(this).serialize(); //Encode form elements for submission
					
					$.ajax({
						url : "DepartmentSqlPage.php",
						type: request_method,
						data : form_data
					}).done(function(response){ 
							alert(response);
						//$("#server-results").html(response);
					});
				});
			});
		</script>
 
