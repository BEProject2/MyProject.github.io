<?php
session_start();

if(!isset($_SESSION["UserName"]))
{
	echo "<script>window.open('home.php');</script>";
}
else
{
	$UserName=$_SESSION["UserName"];
	//$UserId=$_SESSION["UserId"];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="plugins/images/favicon.png">
    <title>WIT</title>
    <!-- Bootstrap Core CSS -->
    <link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="plugins/bower_components/sweetalert/sweetalert.css" rel="stylesheet" type="text/css">
    <link href="plugins/bower_components/bootstrap-extension/css/bootstrap-extension.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css" rel="stylesheet">
	<link href="plugins/bower_components/sweetalert/sweetalert.css" rel="stylesheet" type="text/css">

    <!-- Morris CSS -->
    <!--<link href="plugins/bower_components/morrisjs/morris.css" rel="stylesheet">-->
    <!-- animation CSS -->
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <!-- color CSS -->
    <link href="css/colors/blue.css" id="theme" rel="stylesheet">
	<link href="plugins/bower_components/custom-select/custom-select.css" rel="stylesheet" type="text/css" />
 <link href="plugins/bower_components/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" />
  <link href="plugins/bower_components/datatables/jquery.dataTables.min.css" rel="stylesheet" type="text/css" />
  <style>
	body{
		font-color:black !important;
		font-weight:bolder !important;
		font-size: 13px !important;
	}
  </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <div class="cssload-speeding-wheel"></div>
    </div>
    <div id="wrapper">
        <!-- Navigation -->
		
        <nav class="navbar navbar-default navbar-static-top m-b-0 hidden-print">
            <div class="navbar-header"> <a class="navbar-toggle hidden-sm hidden-md hidden-lg " href="javascript:void(0)" data-toggle="collapse" data-target=".navbar-collapse"><i class="ti-menu"></i></a>
                <div class="top-left-part"><a class="logo" href="index.php"><span class="hidden-xs">
				<!--<strong>Walchand Institute Of Technology,Solapur</strong>-->
				</span></a></div>
                <ul class="nav navbar-top-links navbar-left hidden-xs">
					<img src="plugins/images/users/logo.jpg" width="50" Height="65">
					<strong ><h1 style="color:white">Walchand Institute Of Technology,Solapur</h1></strong>
				
                    <!--<li><a href="javascript:void(0)" class="open-close hidden-xs waves-effect waves-light"><i class="icon-arrow-left-circle ti-menu"></i></a></li>
                    <li>
                        <form role="search" class="app-search hidden-xs">
                            <input type="text" placeholder="Search..." class="form-control"> <a href="#"><i class="fa fa-search"></i></a> </form>
                    </li>-->
                </ul>
              <ul class="nav navbar-top-links navbar-right pull-right">
                      <li class="dropdown">
                        <a class="dropdown-toggle profile-pic" data-toggle="dropdown" href="#"> <img src="plugins/images/img.jpg" alt="user-img" width="36" class="img-circle"><b class="hidden-xs"></b> </a>
                        <ul class="dropdown-menu dropdown-user animated flipInY">
							<li><a href="Logout.php"><i class="fa fa-power-off"></i>  Logout</a></li>
                        </ul>
                    </li>
                    <li class="hidden right-side-toggle"> <a class="waves-effect waves-light" href="javascript:void(0)"><i class="ti-settings"></i></a></li>
                </ul>
            </div>
            <!-- /.navbar-header -->
            <!-- /.navbar-top-links -->
            <!-- /.navbar-static-side -->
        </nav>
        <!-- Left navbar-header -->
        <div class="navbar-default sidebar hidden-print" role="navigation">
            <div class="sidebar-nav navbar-collapse slimscrollsidebar">
                <ul class="nav" id="side-menu">
                    <?php
					if(isset($_SESSION["UserName"]))
					{
						if($_SESSION["Role"]=="HOD")
						{
							$Role=$_SESSION["Role"];
							echo <<<abc
							
							<li> <a href="index.php" class="waves-effect"><i class="fa fa-home p-r-10" data-icon="v"></i> <span class="hide-menu"> Home </span></a></li>
							<li> <a href="LeaveRequestPage.php" class="waves-effect"><i class="fa fa-home p-r-10" data-icon="v"></i> <span class="hide-menu"> Make Leave Request </span></a></li>
							<li> <a href="ViewRequestPage.php" class="waves-effect"><i class="fa fa-home p-r-10" data-icon="v"></i> <span class="hide-menu"> View Employees Leave Request History </span></a></li>
							<li> <a href="UpdateRFID.php" class="waves-effect"><i class="fa fa-home p-r-10" data-icon="v"></i> <span class="hide-menu">Update RFID Number</span></a></li>
							
							</li>
							
							<li>
								<a href="#">
									<i class="fa fa-list nav_icon"></i>&nbsp;&nbsp;Report<span class="fa arrow"></span>
								</a>
								<ul class="nav nav-second-level collapse">
									<li><a href="EmployeeLeaveHistory.php"> View Own Leave History Report</a></li>
									<li><a href="ViewHODLeaveComment.php"> View Comment On Leave</a></li>
									<li><a href="MakeCommentPage.php"> Make Comment Report</a></li>
									<li><a href="ViewAllRequests.php"> View Employee Leave Report</a></li>
								</ul>
							</li>
							<li><a href="Logout.php" class="waves-effect"><i data-icon="P" class="fa fa-sign-out p-r-10"></i><span class="hide-menu">Logout</span></a> 
							</li>									
abc;
						}
						
						else if($_SESSION["Role"]=="Principal")
						{
							$Role=$_SESSION["Role"];
							echo <<<abc
							
							<li> <a href="index.php" class="waves-effect"><i class="fa fa-home p-r-10" data-icon="v"></i> <span class="hide-menu"> Home </span></a></li>
							<li> <a href="DepartmentPage.php" class="waves-effect"><i class="fa fa-home p-r-10" data-icon="v"></i> <span class="hide-menu"> Add New Department </span></a></li>
							<li> <a href="DesignationPage.php" class="waves-effect"><i class="fa fa-home p-r-10" data-icon="v"></i> <span class="hide-menu"> Add New Designation </span></a></li>

							</li>
							
							<li>
								<a href="#">
									<i class="fa fa-list nav_icon"></i>&nbsp;&nbsp;Report<span class="fa arrow"></span>
								</a>
								<ul class="nav nav-second-level collapse">
									<li><a href="ViewRequestPageHOD.php"> View HOD Leave Request Report</a></li>
									<li><a href="PrincipleMakeCommentPage.php"> Make Comment Report</a></li>
									<li><a href="ViewAllRequestsHOD.php"> View HOD Monthly Leave Report</a></li>
								</ul>
							</li>
							<li><a href="Logout.php" class="waves-effect"><i data-icon="P" class="fa fa-sign-out p-r-10"></i><span class="hide-menu">Logout</span></a> 
							</li>									
abc;
						}
						
						else
						{
							$Role=$_SESSION["Role"];
							echo <<<abc
								<li> <a href="home.php" class="waves-effect"><i class="fa fa-home p-r-10" data-icon="v"></i> <span class="hide-menu"> Home </span></a></li>
								<li> <a href="LeaveRequestPage.php" class="waves-effect"><i class="fa fa-home p-r-10" data-icon="v"></i> <span class="hide-menu"> Make Leave Request </span></a></li>
								<li> <a href="UpdateRFID.php" class="waves-effect"><i class="fa fa-home p-r-10" data-icon="v"></i> <span class="hide-menu">Update RFID Number</span></a></li>
								</li>
								<li>
								<a href="#">
									<i class="fa fa-list nav_icon"></i>&nbsp;&nbsp;Report<span class="fa arrow"></span>
								</a>
								<ul class="nav nav-second-level collapse">
									<li><a href="EmployeeLeaveHistory.php"> View Own Leave History Report</a></li>
									<li><a href="EmployeeLeaveComment.php"> View Comment On Leave </a></li>
								</ul>
							</li>
							<li><a href="Logout.php" class="waves-effect"><i data-icon="P" class="fa fa-sign-out p-r-10"></i><span class="hide-menu">Logout</span></a> 
							</li>									
								
abc;
						}
				    }
			?>
                </ul>
            </div>
        </div>
        <!-- Left navbar-header end -->
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">