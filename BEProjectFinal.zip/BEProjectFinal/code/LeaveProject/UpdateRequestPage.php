<?php
		include("connection.php");
		session_start();
		//$EmployeeId=$_SESSION["EmployeeId"];
		$Flag=$_POST["Flag"];
		
		if($Flag=="UpdateD")
		{
			$leaveId=$_POST["Leave_id"];    
			$Status=$_POST["Status"];
			$Comment=$_POST["Comment"];
			if(mysqli_query($con,"UPDATE leave_details SET Status='$Status' WHERE Leave_id='$leaveId'"))
			{
				if($Status!="Pending")
				{
					if(mysqli_query($con,"INSERT INTO leave_status_details(Leave_id,Status,Disapproval_Reason) values('$leaveId','$Status','$Comment')"))
					{
						if($Comment!="none")
							{
								$ida=mysqli_query($con,"SELECT a.Email_id from employee_details a,leave_details b WHERE b.Leave_id='$leaveId' AND a.Employee_id=b.Employee_id");
								$email=$ida->fetch_object()->Email_id;
		
								$Subject="Request Rejected Reason";
								$Body=$Comment;
								$To=$email;
								include_once("mail.php");
								SendMail($Subject,$Body,$To);
							}
						else
							echo "Request Status Updated";
					}
				}
				else
					echo "Request is Still Pending";	
			}
			else
			{
				echo"Failed";
			}
		}
		//mysqli_close($con);
?>