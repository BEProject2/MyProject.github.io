<?php
	include("connection.php");
	$EmpName=$_GET["EmpName"];
	$dept=$_GET["dept"];			//Returns the Department Id value of selected dePT
	$desig=$_GET["desig"];
	$EmailID=$_GET["EmailID"];
	$Cntct=$_GET["Cntct"];
	$Uname=$_GET["Uname"];
	$Pwd=$_GET["Pwd"];
	$rfid=$_GET["rfid"];

	$now=date('Y-m-d');
	$expirationDate = date('Y-m-d', strtotime('+5 years'));

$ida=mysqli_query($con,"SELECT Abbreviation from department_details WHERE Department_id='$dept'");
$dept_abbr=$ida->fetch_object()->Abbreviation;
//echo $dept_abbr;

$rst_EmpId=mysqli_query($con,"select * from employee_details where Department_id='$dept'");
$num=mysqli_num_rows($rst_EmpId);

$Employee_id=$dept_abbr.($num+1);

if(mysqli_query($con,"INSERT INTO employee_details(Employee_id,Employee_name,Department_id,Designation_id,Email_id,Contact_no,Employee_status) VALUES ('$Employee_id','$EmpName','$dept','$desig','$EmailID','$Cntct','Pending')"))
{
	if(mysqli_query($con,"INSERT INTO login_details(Employee_id,Username,Password) VALUES ('$Employee_id','$Uname','$Pwd')"))
	{
		if(mysqli_query($con,"INSERT INTO rfid_details(RFID_Number,Employee_id,Allocation_date,Expiration_date) VALUES ('$rfid','$Employee_id','$now','$expirationDate')"))
		{
			echo "Registration Completed Successfully";
		}
	}
}
else
{
	echo "Registration Failed";
}

//mysqli_close($con);

?>