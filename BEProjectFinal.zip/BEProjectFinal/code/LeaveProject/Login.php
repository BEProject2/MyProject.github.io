<?php include_once("Header1.php");?>
    <!-- Preloader -->
	<center><h3></h3></center>
<form id="LoginPage" class="form-horizontal form-material">
    <div class="preloader">
        <div class="cssload-speeding-wheel"></div>
    </div>
    <section id="wrapper" class="login-register">
        <div class="login-box">
            <div class="white-box">
                    <h3 class="box-title m-b-20">Sign In</h3>
                   
					<div class="form-group ">
                        <div class="col-xs-12">
                            <input class="form-control" id="UserName" name="UserName" type="text" required="" placeholder="Username" autofocus>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-xs-12">
                            <input class="form-control" id="Password" name="Password"  type="password" required="" placeholder="Password" autofocus>
                        </div>
                    </div>
				
					<div class="form-group">
						<div class="col-xs-12">
							<a href="ForgetPasswordPage.php">Forgot Password ?</a>
						</div>
					</div>
					
				
                    <div class="form-group text-center m-t-20">
                        <div class="col-xs-12">
                            <button class="btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light" type="submit">Log In</button>
                        </div>
                    </div>
             
            </div>
        </div>
    </section>
    
</form>

<?php include_once("Footer1.php");?>



<!-- jQuery -->
    <script src="plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/dist/js/tether.min.js"></script>
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.min.js"></script>
    <!--Style Switcher -->
	<script src="plugins/bower_components/sweetalert/sweetalert.min.js"></script>
    <script src="plugins/bower_components/styleswitcher/jQuery.style.switcher.js"></script>
<script>
		$(document).ready(function() 
			{
			  $("#LoginPage").submit(function(event){
					event.preventDefault(); //prevent default action 
					var request_method = $(this).attr("method"); //get form GET/POST method
					var form_data = $(this).serialize(); //Encode form elements for submission
					$.ajax({
						url : "LoginSqlPage.php",
						type: request_method,
						data : form_data
					}).done(function(response)
					{ 
							if(response=="Login Successful")
							{
								//location.href="LeaveRequestPage.php";
								//alert(response);
								location.href="home.php";
							}
							else
							{
								alert("Login Failed");	
								document.getElementById("UserName").value = "";
								document.getElementById("Password").value = "";
							}
					});
				});
			});
</script>