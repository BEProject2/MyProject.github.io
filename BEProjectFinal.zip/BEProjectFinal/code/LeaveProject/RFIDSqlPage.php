<?php
	include("connection.php");
	
	$RFIDNo=$_GET["rfid_no"];
	//$Dept_name=$_GET["dept"];
	$Employee_name=$_GET["empname"];
	$Allocation_Date=$_GET["alloc"];
	$Expiration_Date=$_GET["expr"];
	
	

		// Perform queries

		if(mysqli_query($con,"INSERT INTO rfid_details(RFID_Number,Employee_id,Allocation_date,Expiration_date) VALUES ('$RFIDNo','$Employee_name','$Allocation_Date','$Expiration_Date')"))
		{
				echo"Success";
		}
		else
		{
			echo"Failed";
		}

		//mysqli_close($con);
?>