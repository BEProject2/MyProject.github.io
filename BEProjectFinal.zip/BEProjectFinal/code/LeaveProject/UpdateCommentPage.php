<?php
		include("connection.php");
		
		$Flag=$_POST["Flag"];
		
		if($Flag=="UpdateD")
		{
			$leaveId=$_POST["Leave_id"];    
			$Status=$_POST["Status"];	//Comment or NoComment
			$Comment=$_POST["Comment"];
			$timeDiff=$_POST["timeDiff"];

			if(mysqli_query($con,"INSERT INTO comment_details(Leave_id,Time_Difference,Comment) values('$leaveId','$timeDiff','$Comment')"))
			{
				if($Comment!="none")
					{
								$ida=mysqli_query($con,"SELECT a.Email_id from employee_details a,leave_details b WHERE b.Leave_id='$leaveId' AND a.Employee_id=b.Employee_id");
								$email=$ida->fetch_object()->Email_id;
		
								$Subject="Comment On Leave";
								$Body=$Comment;
								$To=$email;
								include_once("mail.php");
								SendMail($Subject,$Body,$To);
					}
					else
						echo "Request Status Updated";
			}
			else
			{
				echo"Failed";
			}
		}
		//mysqli_close($con);
?>