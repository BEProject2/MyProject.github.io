<?php include_once("Header.php");?>


<form id="ViewAllRequestsReport">
	<div class="row">
		<div class="col-md-3 col-sm-2 col-xs-12">
		</div>
		<div class="col-md-2 col-sm-2 col-xs-12">
			<label for ="Lblmonths">Select Month</label>
		</div>
		<div class="col-md-3 col-sm-2 col-xs-12">
			<select class="form-control" id="month" name="month" placeholder="Choose" onchange="LoadData()">
				<option value="01">January</option>
				<option value="02">February</option>
				<option value="03">March</option>
				<option value="04">April</option>
				<option value="05">May</option>
				<option value="06">June</option>
				<option value="07">July</option>
				<option value="08">August</option>
				<option value="09">September</option>
				<option value="10">October</option>
				<option value="11">November</option>
				<option value="12">December</option>
			</select>
		</div>
	</div>
</form>
<div id='requests'></div>
<?php include_once("Footer.php");?>

<script>
	function LoadData()
	{
		var month=$("#month").val();
		$.post("ViewAllRequestsOperation.php",
			{
					month:month
			},function(data,success)
				{
					//alert(data);
					$("#requests").html(data);
				});
	}
</script>  
