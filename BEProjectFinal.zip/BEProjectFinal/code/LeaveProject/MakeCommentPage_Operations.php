
<?php
	include("connection.php"); 
	$leaveid=$_POST["leaveid"];
	
		$sql = "SELECT Leave_id,Employee_id,Leave_type,Leave_reason,Leave_date,From_time,To_time,Total_Leave_Hours FROM leave_details WHERE Leave_id='$leaveid'";
		$result = $con->query($sql);
		
		if ($result->num_rows > 0) 
		{
			while($row = $result->fetch_assoc()) 
			{
				$Leave_id=$row["Leave_id"];
				$Employee_id=$row["Employee_id"];
				$LeaveType=$row["Leave_type"];
				$LeaveReason=$row["Leave_reason"];
				$LeaveDate=$row["Leave_date"];
				$LeaveFromTime=$row["From_time"];
				$LeaveToTime=$row["To_time"];
				$LeaveTotalHours=$row["Total_Leave_Hours"];
	
				$sql1 = "SELECT RFID_Number,Scan_date,Scan_From_time,Scan_To_time,Scan_Total_Hours FROM rfid_scanner_details WHERE Leave_id='$leaveid' AND Scan_date='$LeaveDate'";
				$result1 = $con->query($sql1);
				if($result1->num_rows > 0)
				{
					while($row1 = $result1->fetch_assoc()) 
					{
						$SwippedLeaveDate=$row1["Scan_date"];
						$SwippedLeaveFromTime=$row1["Scan_From_time"];
						$SwippedLeaveToTime=$row1["Scan_To_time"];
						$SwippedLeaveTotalHours=$row1["Scan_Total_Hours"];
						
						$timeDifference=$LeaveTotalHours-$SwippedLeaveTotalHours;
					}
				}
				else
				{
					$SwippedLeaveFromTime=0;
					$SwippedLeaveToTime=0;
					$SwippedLeaveTotalHours=0;
				}
				$sql2 = "SELECT Employee_Name FROM employee_details WHERE Employee_id ='$Employee_id'";
				$result2 = $con->query($sql2);
				$empName=$result2->fetch_object()->Employee_Name;
				echo "
					<label for ='LblEmpName'>Employee Name</label><input type='text' name='EmpName' id='EmpName' value='$empName' disabled><br>
					<label for ='LblLeaveRequestType'>Leave Request Type</label><input type='text' name='LeaveRequestType' id='LeaveRequestType' value='$LeaveType' disabled><br>
					<label for ='LblLeaveReason'>Leave Reason</label><input type='text' name='LeaveReason' id='LeaveReason' value='$LeaveReason' disabled><br>
					<label for ='LblLeaveDate'>Leave Date</label><input type='text' name='LeaveDate' id='LeaveDate' value='$LeaveDate' disabled><br>
					<label for ='LblLeaveFromTime'>Leave From Time</label><input type='text' name='LeaveFromTime' id='LeaveFromTime' value='$LeaveFromTime' disabled><br>
					<label for ='LblLeaveToTime'>Leave To Time</label><input type='text' name='LeaveToTime' id='LeaveToTime' value='$LeaveToTime' disabled><br>
					<label for ='LblLeaveTotalHours'>Leave Total Hours</label><input type='text' name='LeaveTotalHours' id='LeaveTotalHours' value='$LeaveTotalHours' disabled><br>
					
					<label for ='LblSwippedLeaveFromTime'>Swipped Leave From Time</label><input type='text' name='SwippedLeaveFromTime' id='SwippedLeaveFromTime' value='$SwippedLeaveFromTime' disabled><br>
					<label for ='LblSwippedLeaveToTime'>Swipped Leave To Time</label><input type='text' name='SwippedLeaveToTime' id='SwippedLeaveToTime' value='$SwippedLeaveToTime' disabled><br>
					<label for ='LblSwippedLeaveTotalHours'>Swipped Leave Total Hours</label><input type='text' name='SwippedLeaveTotalHours' id='SwippedLeaveTotalHours' value='$SwippedLeaveTotalHours' disabled><br>
					<label for ='LblTimeDifference'>Time Difference</label><input type='text' name='TimeDifference' id='TimeDifference' value='$timeDifference' disabled><br>

					<label for ='LblLeaveStatus'>Leave Status</label>
							<input type='radio' class='' name='LeaveComment' onchange='Change1($Leave_id,&#39;Accept&#39;)'  value='NoComment' CHECKED>NoComment
							<input type='radio' class='' name='LeaveComment'  onchange='Change1($Leave_id,&#39;Reject&#39;)' value='Comment'>Comment
					
					<div id='commentText' style='display:none'>
					<label for ='LblComment'>Comment</label>
					<input type='text' id='comment' value='none' name='comment'></br>	
					</div>
					<input type='button' id='Save' class='btn-btn success' value='Save' onclick='save($Leave_id)'>
					
					";

				/*$#39 used for '' (single quotes)*/
			}
			
		}
?>
