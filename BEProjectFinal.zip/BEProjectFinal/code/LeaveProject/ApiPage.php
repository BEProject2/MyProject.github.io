<?php
date_default_timezone_set('Asia/Kolkata');
include("connection.php");
$RFID_Number=$_REQUEST["RFID_Number"]; 
$response=array();
$rst=mysqli_query($con,"select * from rfid_details where  RFID_Number='$RFID_Number'");
if(mysqli_num_rows($rst)>0)
{
	$rw=mysqli_fetch_array($rst);
	$empid=$rw["Employee_id"];
	$date1=date("Y-m-d");
	$time1= date("h:i:s");	//date('Y-m-d H:i:s');
	
	
	/*	$time1 = new DateTime($time1);
		$time2 = new DateTime($ToTime);
		$interval = $time1->diff($time2);
		echo $totalHours=$interval->format('%h:%i:%s');
		
	*/
	
	//$time1 = new DateTime("now");
	//$time1=$time1->format('h:i:s');
	$rst1=mysqli_query($con,"select * from leave_details where Employee_id='$empid' and Leave_date='$date1' and From_time<='$time1' and To_time>='$time1' and Status='Accept'");
	//echo "select * from leave_details where  Employee_id='$empid' and Leave_date='$date1'and From_time<='$time1' and To_time>='$time1'";
	if(mysqli_num_rows($rst1)>0)
	{
		$rw1=mysqli_fetch_array($rst1);
		$Leave_id=$rw1["Leave_id"];
		$rst12=mysqli_query($con,"select* from rfid_scanner_details where Leave_id='$Leave_id'");

		if(mysqli_num_rows($rst12)>0)
		{
			$rw12=mysqli_fetch_array($rst12);
			$Scan_From_time=$rw12["Scan_From_time"];
			//$interval = $time1->diff($Scan_From_time);
			//$diff1=$interval->format('h:i:s');
			//$time1=strtotime($time1);
			//$time2=strtotime($Scan_From_time);
			//$diff=$time1-$time2;
			//$time1=date('H:i:s', $time1);

			$s=mysqli_query($con,"UPDATE rfid_scanner_details SET Scan_To_time='$time1' WHERE Leave_id='$Leave_id'");

			$qry = "SELECT TIMEDIFF(Scan_To_time,Scan_From_time) FROM rfid_scanner_details";
			$res=  mysqli_query($con,$qry);
			$row = $res->fetch_assoc();
			$total=$row['TIMEDIFF(Scan_To_time,Scan_From_time)'];
			mysqli_query($con,"update rfid_scanner_details set Scan_Total_Hours='$total' where Leave_id='$Leave_id'");
			$response["Status"]="Success";	
		}
		else
		{
			if(mysqli_query($con,"INSERT INTO rfid_scanner_details(Leave_id,RFID_Number,Scan_From_time,Scan_date) VALUES ('$Leave_id','$RFID_Number','$time1','$date1')"))
				{
						$response["Status"]="Success";
				}
				else
				{
					$response["Status"]="Failed";
				}
		}
	}
	else
	{
		$response["Status"]="Failed1";
	}		
}
else
{
$response["Status"]="Failed2";
}
echo json_encode($response);
//http://localhost/LeaveProject/ApiPage.php?RFID_Number="Your RFID Number"
?>

