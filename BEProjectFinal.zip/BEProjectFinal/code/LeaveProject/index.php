<?php 
include_once("Header1.php"); 
?>
<div class="row bg-title">
	<div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
		<h3 class="page-title">Walchand Institue of Technology,Solapur</h3> </div>
		
	<div class="col-lg-9 col-sm-8 col-md-8 col-xs-12"> 
		
	</div>
</div>
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
      <img src="plugins/images/wit.jpg" alt="..." width="1050" Height="300"> 
</div>
<?php include_once("Footer1.php"); ?>
     