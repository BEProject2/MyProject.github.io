<?php
	include("connection.php"); 
	$leaveid=$_POST["leaveid"];
	
		$sql = "SELECT Leave_id,Employee_id,Leave_type,Leave_reason,Leave_date,From_time,To_time,Total_Leave_Hours FROM leave_details WHERE Leave_id='$leaveid'";
		$result = $con->query($sql);

		if ($result->num_rows > 0) 
		{
			while($row = $result->fetch_assoc()) 
			{
				$Leave_id=$row["Leave_id"];
				$Employee_id=$row["Employee_id"];
				$LeaveType=$row["Leave_type"];
				$LeaveReason=$row["Leave_reason"];
				$LeaveDate=$row["Leave_date"];
				$LeaveFromTime=$row["From_time"];
				$LeaveToTime=$row["To_time"];
				$LeaveTotalHours=$row["Total_Leave_Hours"];
				
				$sql1 = "SELECT Employee_Name FROM employee_details WHERE Employee_id ='$Employee_id'";
				$result1 = $con->query($sql1);
				$empName=$result1->fetch_object()->Employee_Name;
				echo "
					<label for ='LblEmpName'>Employee Name</label><input type='text' name='EmpName' id='EmpName' value='$empName' disabled><br>
					<label for ='LblLeaveRequestType'>Leave Request Type</label><input type='text' name='LeaveRequestType' id='LeaveRequestType' value='$LeaveType' disabled><br>
					<label for ='LblLeaveReason'>Leave Reason</label><input type='text' name='LeaveReason' id='LeaveReason' value='$LeaveReason' disabled><br>
					<label for ='LblLeaveDate'>Leave Date</label><input type='text' name='LeaveDate' id='LeaveDate' value='$LeaveDate' disabled><br>
					<label for ='LblLeaveFromTime'>Leave From Time</label><input type='text' name='LeaveFromTime' id='LeaveFromTime' value='$LeaveFromTime' disabled><br>
					<label for ='LblLeaveToTime'>Leave To Time</label><input type='text' name='LeaveToTime' id='LeaveToTime' value='$LeaveToTime' disabled><br>
					<label for ='LblLeaveTotalHours'>Leave Total Hours</label><input type='text' name='LeaveTotalHours' id='LeaveTotalHours' value='$LeaveTotalHours' disabled><br>
					
					<label for ='LblLeaveStatus'>Leave Status</label>
							<input type='radio' class='' name='LeaveStatus' onchange='Change1($Leave_id,&#39;Pending&#39;)' value='Pending' CHECKED>Pending
							<input type='radio' class='' name='LeaveStatus' onchange='Change1($Leave_id,&#39;Accept&#39;)'  value='Accept'>Accept
							<input type='radio' class='' name='LeaveStatus'  onchange='Change1($Leave_id,&#39;Reject&#39;)' value='Reject'>Reject
					
					<div id='commentText' style='display:none'>
					<label for ='LblComment'>Comment</label>
					<input type='text' id='comment' value='none' name='comment'></br>	
					</div>
					<input type='button' id='Save' class='btn-btn success' value='Save' onclick='save($Leave_id)'>
					
					";

				/*$#39 used for '' (single quotes)*/
			}
			
		}
?>