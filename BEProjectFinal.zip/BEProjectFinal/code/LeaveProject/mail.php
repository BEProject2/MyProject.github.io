<?php
//Common Mailing Function 
//You must include this page in php page like include_once("Mail.php");
// And whenever you want just call the SendMail function with Subject, Body and To parameter
error_reporting(E_ALL);
require_once('PHPMailer_5.2.4/class.phpmailer.php');
function SendMail($Subject,$Body,$To)
{
	$FromUserName="wit.solapurp2dn@gmail.com";
	$FromPassword="witsolapur1234567890";
	$SetFrom="nitesh.pogul@gmail.com";
	$mail = new PHPMailer(); // create a new object
	$mail->IsSMTP(); // enable SMTP
	$mail->SMTPDebug = 2; // debugging: 1 = errors and messages, 2 = messages only
	$mail->SMTPAuth = true; // authentication enabled
	$mail->SMTPSecure = 'tls'; // secure transfer enabled REQUIRED for GMail
	$mail->Host = "smtp.gmail.com";
	$mail->Port = 587; // or 587
	$mail->Username = $FromUserName;
	$mail->Password = $FromPassword;
	//$mail->SetFrom($SetFrom);
	$mail->Subject = $Subject;
//	$mail->Body = $Body;
	$mail->Body = $Body;
 	$mail->IsHTML(true);
	$mail->AddAddress($To);
	if(!$mail->Send())
	{
		return $mail->ErrorInfo;
	}
	else
	{
		return "Mail Sent";
	}
}
SendMail("hi","","nitesh.pogul@gmail.com");
?>