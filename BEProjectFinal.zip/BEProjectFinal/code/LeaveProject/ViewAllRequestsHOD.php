<?php include_once("Header.php");?>

<form id="ViewAllHODRequestsReport">
	<div class="row">
		<div class="col-md-3 col-sm-2 col-xs-12">
		</div>
		<div class="col-md-2 col-sm-2 col-xs-12">
			<label for ="Lblmonths">Select Month</label>
		</div>
		<div class="col-md-3 col-sm-2 col-xs-12">
			<select class="form-control" id="month" name="month" placeholder="Choose" onchange="LoadData()">
				<option value="01">January</option>
				<option value="02">February</option>
				<option value="03">March</option>
				<option value="04">April</option>
				<option value="05">May</option>
				<option value="06">June</option>
				<option value="07">July</option>
				<option value="08">August</option>
				<option value="09">September</option>
				<option value="10">October</option>
				<option value="11">November</option>
				<option value="12">December</option>
			</select>
		</div>
	</div>
</form>
<div id='requests'></div>
<?php include_once("Footer.php");?>

<?php

	include("connection.php");
	//session_start();
	
	//Get Current Month	
	$now = new DateTime('now');
	$month = $now->format('m');
	
	//Fetch All Employee Requests of same department same as subAdmin i.e. $dept_id
	$sql = "SELECT a.Leave_id,a.Employee_id,a.Leave_type,a.Leave_reason,a.Leave_date,a.From_time,a.To_time,a.Total_Leave_Hours,a.Status,b.Department_id FROM leave_details as a,employee_details as b WHERE a.Employee_id=b.Employee_id AND b.Designation_id=5";
	$result = $con->query($sql);

	if ($result->num_rows > 0) {
		echo "<table class='table'><tr><th>LeaveId</th><th>EmployeeId</th><th>LeaveType</th><th>LeaveReason</th><th>LeaveDate</th><th>LeaveFromTime</th><th>LeaveToTime</th><th>TotalLeaveHours</th><th>Status</th></tr>";

		while($row = $result->fetch_assoc()) {
			$leaveId=$row["Leave_id"];
			$empId=$row["Employee_id"];
			$LeaveType=$row["Leave_type"];
			$LeaveReason=$row["Leave_reason"];
			$LeaveDate=$row["Leave_date"];
			//Getting month from LeaveDate
			$now1 = new DateTime($LeaveDate);
			$month1 = $now1->format('m');
		
			$LeaveFromTime=$row["From_time"];
			$LeaveToTime=$row["To_time"];
			$LeaveTotalHours=$row["Total_Leave_Hours"];
			$Status=$row["Status"];		
			if($month==$month1)
				echo "<tr><td>".$leaveId."</td><td>".$empId."</td><td>".$LeaveType."</td><td>".$LeaveReason."</td><td>".$LeaveDate."</td><td>".$LeaveFromTime."</td><td>".$LeaveToTime."</td><td>".$LeaveTotalHours."</td><td>".$Status."</td></tr>";
		}
		echo "</table>";
	} 
	else {
		echo "No more Requests";
	}
	//$con->close();
?>




<script>
	function LoadData()
	{
		var month=$("#month").val();
		$.post("ViewAllHODRequestsOperation.php",
			{
					month:month
			},function(data,success)
				{
					//alert(data);
					$("#requests").html(data);
				});
	}
</script>  


  
