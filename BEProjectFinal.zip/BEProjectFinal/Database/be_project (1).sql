-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 03, 2018 at 01:31 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `be_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment_details`
--

CREATE TABLE IF NOT EXISTS `comment_details` (
  `Comment_id` int(20) NOT NULL AUTO_INCREMENT,
  `Leave_id` int(20) NOT NULL,
  `Time_Difference` text NOT NULL,
  `Comment` text NOT NULL,
  PRIMARY KEY (`Comment_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `comment_details`
--

INSERT INTO `comment_details` (`Comment_id`, `Leave_id`, `Time_Difference`, `Comment`) VALUES
(9, 14, '0', 'none');

-- --------------------------------------------------------

--
-- Table structure for table `department_details`
--

CREATE TABLE IF NOT EXISTS `department_details` (
  `Department_id` int(20) NOT NULL AUTO_INCREMENT,
  `Department` text NOT NULL,
  `Abbreviation` text NOT NULL,
  PRIMARY KEY (`Department_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `department_details`
--

INSERT INTO `department_details` (`Department_id`, `Department`, `Abbreviation`) VALUES
(1, 'General', 'Gen'),
(2, 'Computer engineering', 'CSE'),
(3, 'Information Technology', 'IT'),
(4, 'Mechanical Engineering', 'MECH'),
(5, 'Civil Engineering', 'CE'),
(6, 'Electronics Engineering', 'ELN'),
(7, 'Electronics and Telecommunication Engineering', 'ENTC');

-- --------------------------------------------------------

--
-- Table structure for table `designation_details`
--

CREATE TABLE IF NOT EXISTS `designation_details` (
  `Designation_id` int(20) NOT NULL AUTO_INCREMENT,
  `Designation` text NOT NULL,
  PRIMARY KEY (`Designation_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `designation_details`
--

INSERT INTO `designation_details` (`Designation_id`, `Designation`) VALUES
(1, 'General'),
(2, 'Teaching'),
(3, 'NonTeaching'),
(4, 'LabAssistant'),
(5, 'HOD'),
(6, 'Principal');

-- --------------------------------------------------------

--
-- Table structure for table `employee_details`
--

CREATE TABLE IF NOT EXISTS `employee_details` (
  `Employee_id` varchar(20) NOT NULL,
  `Employee_Name` text NOT NULL,
  `Department_id` int(20) NOT NULL,
  `Designation_id` int(20) NOT NULL,
  `Email_id` varchar(50) NOT NULL,
  `Contact_no` text NOT NULL,
  `Employee_status` text NOT NULL,
  PRIMARY KEY (`Employee_id`),
  KEY `Department_id` (`Department_id`),
  KEY `Department_id_2` (`Department_id`),
  KEY `Department_id_3` (`Department_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee_details`
--

INSERT INTO `employee_details` (`Employee_id`, `Employee_Name`, `Department_id`, `Designation_id`, `Email_id`, `Contact_no`, `Employee_status`) VALUES
('1', 'Admin', 0, 6, 'buranamrata25@gmail.com', '8794615979', 'Pending'),
('CSE1', 'Priyanka', 2, 2, 'devsanipriyanka@gmail.com', '8657154055', 'Pending'),
('CSE2', 'Namrata', 2, 5, 'buranamrata25@gmail.com', '7745896521', 'Pending'),
('CSE3', 'Pradnya', 2, 2, 'pradnyadudam04@gmail.com', '7745865343', 'Pending'),
('IT1', 'Pratibha', 3, 2, 'domalpratibha@gmail.com', '9898767656', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `leave_details`
--

CREATE TABLE IF NOT EXISTS `leave_details` (
  `Leave_id` int(20) NOT NULL AUTO_INCREMENT,
  `Employee_id` varchar(20) NOT NULL,
  `Leave_type` text NOT NULL,
  `Leave_reason` text NOT NULL,
  `Leave_date` date NOT NULL,
  `From_time` time NOT NULL,
  `To_time` time NOT NULL,
  `Total_Leave_Hours` time NOT NULL,
  `Status` text NOT NULL,
  PRIMARY KEY (`Leave_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `leave_details`
--

INSERT INTO `leave_details` (`Leave_id`, `Employee_id`, `Leave_type`, `Leave_reason`, `Leave_date`, `From_time`, `To_time`, `Total_Leave_Hours`, `Status`) VALUES
(14, 'CSE1', 'Organization', 'Seminar', '2018-03-22', '12:00:00', '15:00:00', '03:00:00', 'Accept'),
(15, 'CSE2', 'Organization', 'Seminar', '2018-03-25', '13:00:00', '15:00:00', '02:00:00', 'Pending'),
(16, 'CSE2', 'Personal', 'Prblm', '2018-03-30', '12:00:00', '13:00:00', '01:00:00', 'Pending'),
(17, 'CSE3', 'Organization', 'Seminar', '2018-04-03', '14:00:00', '16:30:00', '02:30:00', 'Accept'),
(18, 'CSE3', 'Organization', 'hgjh', '2018-04-24', '18:33:00', '18:43:00', '02:00:00', 'Accept'),
(19, 'CSE3', 'Organization', 'Seminar', '2018-04-25', '03:00:00', '06:00:00', '03:00:00', 'Accept'),
(20, 'CSE2', 'Personal', 'HEeadAch', '2018-04-10', '13:00:00', '14:00:00', '01:00:00', 'Pending'),
(21, 'CSE3', 'Personal', 'Health issue', '2018-04-26', '13:00:00', '14:00:00', '01:00:00', 'Accept');

-- --------------------------------------------------------

--
-- Table structure for table `leave_status_details`
--

CREATE TABLE IF NOT EXISTS `leave_status_details` (
  `Leave_Status_Details_id` int(20) NOT NULL AUTO_INCREMENT,
  `Leave_id` int(20) NOT NULL,
  `Status` text NOT NULL,
  `Disapproval_Reason` text NOT NULL,
  PRIMARY KEY (`Leave_Status_Details_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `leave_status_details`
--

INSERT INTO `leave_status_details` (`Leave_Status_Details_id`, `Leave_id`, `Status`, `Disapproval_Reason`) VALUES
(35, 14, 'Accept', 'none'),
(36, 17, 'Accept', 'none'),
(37, 18, 'Reject', 'Hello'),
(38, 21, 'Accept', 'none');

-- --------------------------------------------------------

--
-- Table structure for table `login_details`
--

CREATE TABLE IF NOT EXISTS `login_details` (
  `Login_id` int(20) NOT NULL AUTO_INCREMENT,
  `Employee_id` varchar(20) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  PRIMARY KEY (`Login_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `login_details`
--

INSERT INTO `login_details` (`Login_id`, `Employee_id`, `Username`, `Password`) VALUES
(9, '1', 'admin', 'admin'),
(10, 'CSE1', 'priyanka', 'priya'),
(12, 'CSE2', 'Namrata', '111'),
(13, 'CSE3', 'pradnya', '123'),
(14, 'IT1', 'Pratibha', 'pratibha');

-- --------------------------------------------------------

--
-- Table structure for table `rfid_details`
--

CREATE TABLE IF NOT EXISTS `rfid_details` (
  `RFID_Number` text NOT NULL,
  `Employee_id` varchar(20) NOT NULL,
  `Allocation_date` date NOT NULL,
  `Expiration_date` date NOT NULL,
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `rfid_details`
--

INSERT INTO `rfid_details` (`RFID_Number`, `Employee_id`, `Allocation_date`, `Expiration_date`, `ID`) VALUES
('26:1D:E4:12', 'CSE3', '2018-04-17', '2023-04-17', 1);

-- --------------------------------------------------------

--
-- Table structure for table `rfid_scanner_details`
--

CREATE TABLE IF NOT EXISTS `rfid_scanner_details` (
  `RFID_Scanner_Details_id` int(20) NOT NULL AUTO_INCREMENT,
  `Leave_id` int(20) NOT NULL,
  `RFID_Number` varchar(20) NOT NULL,
  `Scan_date` date NOT NULL,
  `Scan_From_time` time NOT NULL,
  `Scan_To_time` time NOT NULL,
  `Scan_Total_Hours` time NOT NULL,
  PRIMARY KEY (`RFID_Scanner_Details_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `rfid_scanner_details`
--

INSERT INTO `rfid_scanner_details` (`RFID_Scanner_Details_id`, `Leave_id`, `RFID_Number`, `Scan_date`, `Scan_From_time`, `Scan_To_time`, `Scan_Total_Hours`) VALUES
(1, 14, '12345', '2018-03-22', '12:00:00', '15:00:00', '00:00:00'),
(2, 15, '111', '2018-03-25', '13:00:00', '14:00:00', '00:00:00'),
(3, 16, '111', '2018-03-30', '12:00:00', '13:00:00', '00:00:00'),
(4, 14, '12345', '2018-03-22', '12:00:00', '15:00:00', '00:00:00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
